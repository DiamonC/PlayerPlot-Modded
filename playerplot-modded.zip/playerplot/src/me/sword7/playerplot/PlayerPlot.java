package me.sword7.playerplot;

import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import com.github.yannicklamprecht.worldborder.api.WorldBorderApi;

import me.sword7.playerplot.admin.CommandAllPlots;
import me.sword7.playerplot.admin.CommandDelPlot;
import me.sword7.playerplot.admin.CommandDelPlotCancel;
import me.sword7.playerplot.admin.CommandDelPlotConfirm;
import me.sword7.playerplot.config.ConfigLoader;
import me.sword7.playerplot.config.Language;
import me.sword7.playerplot.config.PluginBase;
import me.sword7.playerplot.config.PluginConfig;
import me.sword7.playerplot.config.Version;
import me.sword7.playerplot.modded.ArionasConfig;
import me.sword7.playerplot.modded.ArionasEvent;
import me.sword7.playerplot.modded.BuyDeedCommand;
import me.sword7.playerplot.plot.CommandPlot;
import me.sword7.playerplot.plot.CommandToPlot;
import me.sword7.playerplot.plot.PlotBeam;
import me.sword7.playerplot.plot.PlotCache;
import me.sword7.playerplot.plot.PlotListener;
import me.sword7.playerplot.plot.PlotScanner;
import me.sword7.playerplot.plot.ProtectionListener;
import me.sword7.playerplot.plotdeed.CommandLoot;
import me.sword7.playerplot.plotdeed.CommandWriteDeed;
import me.sword7.playerplot.plotdeed.PlotDeedListener;
import me.sword7.playerplot.plotdeed.PlotDeedLoot;
import me.sword7.playerplot.plotdeed.PlotDeedType;
import me.sword7.playerplot.user.UserCache;
import me.sword7.playerplot.util.AutoCompleteListener;
import me.sword7.playerplot.util.border.Border;
import me.sword7.playerplot.util.storage.DatabaseConnection;
import net.milkbowl.vault.economy.Economy;

public final class PlayerPlot extends JavaPlugin {

	public static PlayerPlot instance;
	
    private static Plugin plugin;
    private PlayerPlotAPI playerPlotAPI = PlayerPlotAPI.getInstance();

    public WorldBorderApi worldBorderApi;
    
    public ArionasConfig arionasConfig;
    
    public Economy econ = null;
    public boolean usingVault = false;
    
    @Override
    public void onEnable() {
    	instance = this;
        plugin = this;
     
        RegisteredServiceProvider<WorldBorderApi> worldBorderApiRegisteredServiceProvider = getServer().getServicesManager().getRegistration(WorldBorderApi.class);

        if (worldBorderApiRegisteredServiceProvider == null) {
            getLogger().info("API not found");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        worldBorderApi = worldBorderApiRegisteredServiceProvider.getProvider();

        setupEconomy();
        
        //configs
        ConfigLoader.load();
        new PluginConfig();
        
        arionasConfig = new ArionasConfig();

        //language and enums that use language
        Language.load();
        PlotDeedType.init();

        //load integrations
        new PluginBase();

        //initialize caches
        new PlotCache();
        new UserCache();

        //register commands
        getCommand("playerplot").setExecutor(new CommandPlayerPlot());
        getCommand(PluginConfig.getRootCommand()).setExecutor(new CommandPlot());
        getCommand("plotdeed").setExecutor(new CommandLoot(new PlotDeedLoot()));
        getCommand("toplot").setExecutor(new CommandToPlot());
        getCommand("writedeed").setExecutor(new CommandWriteDeed());
        getCommand("allplots").setExecutor(new CommandAllPlots());
        getCommand("delplot").setExecutor(new CommandDelPlot());
        getCommand("delplotconfirm").setExecutor(new CommandDelPlotConfirm());
        getCommand("delplotcancel").setExecutor(new CommandDelPlotCancel());
        getCommand("buydeed").setExecutor(new BuyDeedCommand());

        //register listeners
        if (Version.hasAutoComplete()) new AutoCompleteListener();
        new ProtectionListener();
        new PlotListener();
        new PlotDeedListener();
        new PlotScanner();
        
        new ArionasEvent();

    }

    @Override
    public void onDisable() {
        if (PluginBase.isDynmapDetected()) {
            PluginBase.getDynmap().shutdown();
        }
        try {
        	UserCache.shutdown();
            PlotCache.shutdown();
            if (PluginConfig.isUsingDatabase()) DatabaseConnection.shutdown();
            Border.shutdown();
            PlotBeam.shutdown();
        } catch(Exception ex) {
        	this.getLogger().warning("Could not disable plugin properly!");
        }
        
    }

    public static void reload() {
        ConfigLoader.load();
        PluginConfig.reload();
        Language.reload();
        //TODO - update perm info with new maxPlots from reload (or only load in if has override and compare greater on unlock)
        //TODO - add plot file/database reload once new storage system is implemented
    }

    public static Plugin getPlugin() {
        return plugin;
    }

    public PlayerPlotAPI getPlayerPlotAPI() {
        return playerPlotAPI;
    }
    
    public boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
        	System.out.println("exit1");
            return false;
        }
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
        	System.out.println("exit2");
            return false;
        }
        
        usingVault = true;
        econ = rsp.getProvider();
        return econ != null;
    }


}
