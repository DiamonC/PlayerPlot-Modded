package me.sword7.playerplot.modded;

import java.util.List;
import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import me.sword7.playerplot.PlayerPlot;
import me.sword7.playerplot.config.PluginBase;
import me.sword7.playerplot.integration.Dynmap;
import me.sword7.playerplot.plot.Plot;
import me.sword7.playerplot.plot.PlotCache;
import me.sword7.playerplot.plot.PlotScanner;
import me.sword7.playerplot.util.X.XSound;

public class ArionasEvent implements Listener {

	private boolean usingDynmap = PluginBase.isDynmapDetected();
    private Dynmap dynmap = PluginBase.getDynmap();
	
	public ArionasEvent() {
		// Register event when constructor is called
		Bukkit.getServer().getPluginManager().registerEvents(this, PlayerPlot.instance);
	}
	
	@EventHandler
	public void onItemBurn(EntityCombustEvent event) {
		Entity en = event.getEntity();
		if(en instanceof Item) {
			ItemStack item = ((Item) en).getItemStack();
			
			if(item.getType() != Material.PLAYER_HEAD) return;
			if(!item.hasItemMeta()) return;
			
			SkullMeta meta = (SkullMeta) item.getItemMeta();
			if(meta == null) return;
			
			OfflinePlayer player = meta.getOwningPlayer();
			
			//System.out.println(player.getName());
			deletePlot(player.getPlayer());
		}
	}
	
	@EventHandler
	public void onPlayerDeath(EntityDeathEvent event) {
		Entity en = event.getEntity();
		if(en instanceof Player) {
			Player player = (Player) event.getEntity();
			event.getDrops().add(getPlayerHead(player));
		}
	}
	
	// Delete a random Plot
	private void deletePlot(Player owner) {
		
		List<Plot> plots = PlotCache.getPlayerPlots(owner.getUniqueId());
		if(plots.size() <= 0) return;
		
		Plot plot = plots.get((new Random()).nextInt(plots.size()));
		
		PlotScanner.showPlot(owner, plot, 1);
        PlotCache.removePlot(plot);
        if (usingDynmap) dynmap.deletePlot(plot);
        //owner.sendMessage(Language.SUCCESS_PLOT_FREE.coloredFromPlot(plot.getName(), ChatColor.LIGHT_PURPLE, ChatColor.DARK_PURPLE));
        Bukkit.broadcastMessage(PlayerPlot.instance.arionasConfig.getBurnMessage(owner.getName(), plot.getCenter().getX(), plot.getCenter().getZ()));
        if (XSound.BLOCK_BEACON_DEACTIVATE.isSupported()) {
            owner.playSound(owner.getLocation(), XSound.BLOCK_BEACON_DEACTIVATE.parseSound(), 1f, 1f);
        }
		
	}
	
	// Utility method to get a skull item with head's skin
	private ItemStack getPlayerHead(Player head) {
		ItemStack skullItem = new ItemStack(Material.PLAYER_HEAD);
    	SkullMeta skullMeta = (SkullMeta)skullItem.getItemMeta();
    	skullMeta.setOwningPlayer(head);
    	//skullMeta.setDisplayName(PlayerPlot.instance.arionasConfig.getHeadItemName(head.getName()));
    	skullMeta.setLore(PlayerPlot.instance.arionasConfig.getHeadItemLore(head.getName()));
    	skullItem.setItemMeta(skullMeta);
    	ItemMeta meta = skullItem.getItemMeta();
    	meta.setDisplayName(PlayerPlot.instance.arionasConfig.getHeadItemName(head.getName()));
    	skullItem.setItemMeta(meta);
    	return skullItem;
	}
	
}
