package me.sword7.playerplot.modded;

import java.util.Map;
import java.util.UUID;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import me.sword7.playerplot.PlayerPlot;
import me.sword7.playerplot.config.Language;
import me.sword7.playerplot.config.PluginConfig;
import me.sword7.playerplot.plot.PlotCache;
import me.sword7.playerplot.plotdeed.PlotDeedType;
import me.sword7.playerplot.user.UserCache;
import me.sword7.playerplot.user.UserData;
import me.sword7.playerplot.util.PermInfo;

public class BuyDeedCommand implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		if(!(sender instanceof Player)) return false;
		
		PlayerPlot pp = PlayerPlot.instance;
		
		Player player = (Player) sender;
		if(player.hasPermission(pp.arionasConfig.buyDeedPermission)) {
			int amount = 1;
			
			if(args.length >= 1) {
				try {
					amount = Integer.parseInt(args[0]);
				} catch(Exception ex) {
					player.sendMessage(pp.arionasConfig.getBuyDeedCorrection());
					return false;
				}
			}
			
			double cost = pp.arionasConfig.getPlotDeedCost() * amount;
			
			if(pp.usingVault) {
				if(pp.econ.getBalance(player) >= cost) {
					givePlotDeedItem(player, amount);
					pp.econ.withdrawPlayer(player, cost);
					
				} else {
					player.sendMessage(pp.arionasConfig.getNotEnoughMoney(cost));
				}
			}
			
			return true;
		} 
		
		sender.sendMessage(ChatColor.RED + Language.WARN_NOT_PERMITTED.toString());
		return false;
	}

	private void givePlotDeedItem(Player player, int amount) {
		UUID id = player.getUniqueId();
		
		if (UserCache.hasData(id)) {
            int deedsToWrite = amount;
            UserData userData = UserCache.getData(id);
            PermInfo permInfo = UserCache.getPerms(id);
            int unlockedPlots = userData.getUnlockedPlots();
            if (unlockedPlots > 0) {
                int unplacedPlots = PluginConfig.getStartingPlotNum() + unlockedPlots + permInfo.getPlotBonus() - PlotCache.getPlayerPlotsUsed(id);
                int availableDeeds = Math.min(unlockedPlots, unplacedPlots);
                if (availableDeeds >= deedsToWrite) {
                    Map<Integer, ItemStack> overflow = player.getInventory().addItem(PlotDeedType.DEFAULT.getPlotDeed().getItemStack(deedsToWrite));
                    int unSuccessful = 0;
                    for (ItemStack overItem : overflow.values()) {
                        unSuccessful += overItem.getAmount();
                    }
                    int writtenDeeds = deedsToWrite - unSuccessful;
                    userData.lockPlots(writtenDeeds);
                    player.sendMessage(ChatColor.LIGHT_PURPLE + Language.SUCCESS_WRITE_DEED.fromAmount(writtenDeeds));
                } else {
                    player.sendMessage(ChatColor.RED + Language.WARN_INSUFFICIENT_UNCLAIMED_PLOTS.toString());
                }
            } else {
                player.sendMessage(ChatColor.RED + Language.WARN_NO_UNLOCKED_PLOTS.toString());
            }
        }
		
	}
	
}
