package me.sword7.playerplot.modded;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import org.bukkit.permissions.Permission;

import me.sword7.playerplot.PlayerPlot;

public class ArionasConfig {

	private YamlParser y;
	public Permission buyDeedPermission;
	
	public ArionasConfig() {
		y = new YamlParser(PlayerPlot.instance.getDataFolder(), "modded.yml", "");
		buyDeedPermission = new Permission("playerplot.modded.buydeed");
		PlayerPlot.instance.getServer().getPluginManager().addPermission(buyDeedPermission);
	}
	
	public String getBurnMessage(String owner, float locX, float locZ) {
		String s = y.getConfig().getString("BurnMessage").replace('&', '§');
		s = s.replace("{owner}", owner);
		s = s.replace("{locX}", ""+round(locX, 1));
		s = s.replace("{locZ}", ""+round(locZ, 1));
		return s;
	}
	
	public String getHeadItemName(String owner) {
		String s = y.getConfig().getString("HeadName").replace('&', '§');
		s = s.replace("{owner}", owner);
		return s;
	}
	
	public List<String> getHeadItemLore(String owner) {
		List<String> list = new ArrayList<>();
		for(String s : y.getConfig().getStringList("HeadLore")) {
			s = s.replace('&', '§');
			s = s.replace("{owner}", owner);
			list.add(s);
		}
		return list;
	}
	
	public double getPlotDeedCost() {
		return y.getConfig().getDouble("PlotDeedCost");
	}
	
	public String getNotEnoughMoney(double money) {
		String s = y.getConfig().getString("NotEnoughMoney").replace('&', '§');
		s = s.replace("{money}", ""+round(money,2));
		return s;
	}
	
	public String getBuyDeedCorrection() {
		return y.getConfig().getString("BuyDeedCorrection").replace('&', '§');
	}
	
	private double round(double value, int places) {
		if(places < 0) return (int) value;
		BigDecimal bd = new BigDecimal(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}
	
}
