package me.sword7.playerplot.modded;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;

import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import me.sword7.playerplot.PlayerPlot;

public class YamlParser {

	private FileConfiguration config;
	
	public YamlParser(File directory, String fileName, String folderName) {
		
		String resourceDir = folderName.isEmpty() ? fileName : folderName+"/"+fileName;
		String trueDir = folderName.isEmpty() ? directory+"/"+fileName : directory+"/"+folderName+"/"+fileName;
		
		if(!directory.exists()) directory.mkdirs();
		
		File f = new File(trueDir);
		if(!f.exists()) {
			f.getParentFile().mkdirs();
			PlayerPlot.instance.saveResource(resourceDir, true);
		}
		
		config = new YamlConfiguration();
		
		try {
			config.load(trueDir);
		} catch(InvalidConfigurationException | IOException e) {
			PlayerPlot.instance.getLogger().log(Level.SEVERE, "Could not load "+directory+"\\"+fileName);
			PlayerPlot.instance.getLogger().log(Level.SEVERE, "StackTrace: ");
			e.printStackTrace();
		}
		
	}
	
	public FileConfiguration getConfig() {
		return this.config;
	}
	
}
