package me.sword7.playerplot.util.storage;

public interface CallbackQuery<T> {

    void onQueryDone(T t);

}
