package me.sword7.playerplot.util.border;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

import me.sword7.playerplot.PlayerPlot;

public class Border_v1_18_R2 implements IBorder {

	@Override
	public void show(Player player, World world, double x, double z, double size) {
		
		Location loc = new Location(world, x, player.getLocation().getY(), z);
		PlayerPlot.instance.worldBorderApi.setBorder(player, size, loc);
		
	}

	@Override
	public void hide(Player player, World world) {
		
		PlayerPlot.instance.worldBorderApi.resetWorldBorderToGlobal(player);
		
	}

	
	
}
