package me.sword7.playerplot.util.border;

import org.bukkit.World;
import org.bukkit.entity.Player;

public class Border_Unknown implements IBorder {

    @Override
    public void show(Player player, World world, double x, double z, double length) {

    }

    @Override
    public void hide(Player player, World world) {

    }

}
