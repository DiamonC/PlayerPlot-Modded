package me.sword7.playerplot.util.border;

import java.util.UUID;

import org.bukkit.World;

public class ClientBorder {

    private UUID id;
    private World world;
    private PlayerPusher playerPusher;

    public ClientBorder(World world) {
        this.id = UUID.randomUUID();
        this.world = world;
    }

    public void setPlayerPusher(PlayerPusher playerPusher) {
        this.playerPusher = playerPusher;
    }

    public UUID getId() {
        return id;
    }

    public World getWorld() {
        return world;
    }

    public void stopPusher() {
        if (playerPusher != null && !playerPusher.isCancelled()) {
            playerPusher.cancel();
        }
    }

}
